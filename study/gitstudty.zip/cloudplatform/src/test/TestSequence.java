package test;

import com.bienCloud.core.common.util.SequenceUtils;

/**
 * Sequence测试(客户端)
 */
 public class TestSequence {
     /**
      * 测试入口
      * @param args
      */
     public static void main(String args[]) {
         test();
     }


     /**
      * 测试Sequence方法
      */
     public static void test() {
         System.out.println("----------test()----------");
         for (int i = 0; i < 20; i++) {
             long x = SequenceUtils.getInstance().getNextKeyValue("count");
             System.out.println(x);
         }
     }
 }
