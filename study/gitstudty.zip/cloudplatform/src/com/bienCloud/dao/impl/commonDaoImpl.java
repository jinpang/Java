package com.bienCloud.dao.impl;

import com.bienCloud.core.dao.BaseHibernateDaoSupport;
import com.bienCloud.dao.CommonDao;
import com.bienCloud.platform.po.TCompany;
import com.bienCloud.platform.po.TUser;

@SuppressWarnings("rawtypes")
public class commonDaoImpl  extends BaseHibernateDaoSupport  implements CommonDao {

}
