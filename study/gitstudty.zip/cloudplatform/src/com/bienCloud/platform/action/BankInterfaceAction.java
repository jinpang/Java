package com.bienCloud.platform.action;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bienCloud.core.action.BaseAction;
import com.bienCloud.platform.service.BankInterfaceService;

public class BankInterfaceAction extends BaseAction {
	
	private BankInterfaceService bankInterfaceService;
	private List<String> listFile;
	private Map<String, String> mapKeyValue;
	private String configFileName;
	
	/**
	 * 配置银行基本信息
	 * @return
	 */	
	public String doBankConfig(){
		return SUCCESS;
	}
	 
	public String configFile(){
		return SUCCESS;
	}
	
	public String goAddConfigFile(){
		return SUCCESS;
	}
	
	public String deleteConfigFile(){
	  msg = bankInterfaceService.deleteConfigFile(configFileName);
	  outMsg(msg);
	  return null;	
	}
	
	public String configFileList(){
		listFile = bankInterfaceService.getFileNames();
	   return SUCCESS;	
	}
	
	public String addConfigFile(){
	    msg = bankInterfaceService.addConfigFile(getParametersToMap());
	    outMsg(msg);
		return SUCCESS;
	}
	
	public String goEditConfigFile(){
		init();
		mapKeyValue = bankInterfaceService.getPropertiesToMap(configFileName);
		return SUCCESS;
	}
	
	public String editConfigFile(){
	    msg = bankInterfaceService.editConfigFile(getParametersToMap());
	    outMsg(msg);
		return SUCCESS;
	}
	
	public Map<Object, Object> getParametersToMap(){
		Map<Object, Object> m = new HashMap<Object, Object>();
		init();
		Enumeration keyNames = request.getParameterNames();
		while(keyNames.hasMoreElements()){
			String k = keyNames.nextElement().toString();
			String v = request.getParameter(k);
			m.put(k, v);
		}
		return m;
	}
	
	public BankInterfaceService getBankInterfaceService() {
		return bankInterfaceService;
	}
	
	public void setBankInterfaceService(BankInterfaceService bankInterfaceService) {
		this.bankInterfaceService = bankInterfaceService;
	}
	
	public List<String> getListFile() {
		return listFile;
	}
	public void setListFile(List<String> listFile) {
		this.listFile = listFile;
	}
	
	public String getConfigFileName() {
		return configFileName;
	}
	
	public void setConfigFileName(String configFileName) {
		this.configFileName = configFileName;
	}

	public Map<String, String> getMapKeyValue() {
		return mapKeyValue;
	}

	public void setMapKeyValue(Map<String, String> mapKeyValue) {
		this.mapKeyValue = mapKeyValue;
	}
	
}
