package com.bienCloud.platform.action;

import java.util.List;

import com.bienCloud.core.action.BaseAction;
import com.bienCloud.core.common.dto.CommonDto;
import com.bienCloud.platform.action.model.OweRecordModel;
import com.bienCloud.platform.po.TOweRecord;
import com.bienCloud.platform.po.TUser;
import com.bienCloud.platform.service.OweRecordService;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("serial")
public class OweRecordAction extends BaseAction implements  ModelDriven<OweRecordModel>{
	
	private OweRecordService oweRecordService;
	private OweRecordModel oweRecordModel = new OweRecordModel();
	


	public String oweRecordList(){
//		updateUserList("");
		checkOweRecordList();
		return SUCCESS;
	}

	public String checkOweRecordList() {
		init();
		StringBuffer hql = new StringBuffer(" where 1=1 ");
		TOweRecord oweRecord = oweRecordModel.getOweRecord();
		Object obj = session.getAttribute("user");
		TUser user = null;
		if (obj != null) {
			user = (TUser) obj;
			if (user.getAccount() != null && user.getAccount().getId() != null) {
				hql.append(" and account.id=" + user.getAccount().getId());
			}

			if (oweRecord != null) {
				if (oweRecord.getType() != null
						&& !oweRecord.getType().equals(-1)) {
					hql.append(" and type = " + oweRecord.getType());
				}
				if (oweRecordModel.getOweStartTime() != null) {
					hql.append(" and changeTime >= '"
							+ oweRecordModel.getOweStartTime() + "'");
				}
				if (oweRecordModel.getOweEndTime() != null) {
					hql.append(" and changeTime <= '"
							+ oweRecordModel.getOweEndTime() + "'");
				}
			}
		}else{
			hql.append(" and 1=2 ");
		}
		updateUserList(hql.toString());
		return SUCCESS;
	}
	
	public void updateUserList(String hql){
		CommonDto dto = (CommonDto) oweRecordService.getResult(pageSize,
				cpage - 1, " TOweRecord ", hql.toString());
		resultList = (List) dto.getProperty("result");
		Integer pageCount = (Integer) dto.getProperty("pageCount");
		this.setTotal(pageCount);
	}

	public OweRecordService getOweRecordService() {
		return oweRecordService;
	}

	public void setOweRecordService(OweRecordService oweRecordService) {
		this.oweRecordService = oweRecordService;
	}

	public OweRecordModel getModel() {
		return oweRecordModel;
	}
	
}
