package com.bienCloud.platform.action.model;

import java.sql.Timestamp;

import com.bienCloud.platform.po.TOweRecord;
import com.bienCloud.platform.po.TTradeRecord;

public class OweRecordModel {
	
    private TOweRecord oweRecord;
    private Timestamp oweStartTime;
    private Timestamp oweEndTime;
    
	public TOweRecord getOweRecord() {
		return oweRecord;
	}
	public void setOweRecord(TOweRecord oweRecord) {
		this.oweRecord = oweRecord;
	}
	public Timestamp getOweStartTime() {
		return oweStartTime;
	}
	public void setOweStartTime(Timestamp oweStartTime) {
		this.oweStartTime = oweStartTime;
	}
	public Timestamp getOweEndTime() {
		return oweEndTime;
	}
	public void setOweEndTime(Timestamp oweEndTime) {
		this.oweEndTime = oweEndTime;
	}

}
