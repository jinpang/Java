package com.bienCloud.platform.po;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * TUser entity. @author MyEclipse Persistence Tools
 */

public class TOweRecord implements java.io.Serializable {

	// Fields

	private Integer id;
	private TAccount account;
	private Integer type;
	private String content;
	private Timestamp changeTime;

	// Constructors

	/** default constructor */
	public TOweRecord() {
	}

	/** full constructor */
	public TOweRecord(Integer id, TAccount account, Integer type, String content,
			Timestamp changeTime) {
		super();
		this.id = id;
		this.account = account;
		this.type = type;
		this.content = content;
		this.changeTime = changeTime;
	}

	// Property accessors
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TAccount getAccount() {
		return account;
	}

	public void setAccount(TAccount account) {
		this.account = account;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Timestamp getChangeTime() {
		return changeTime;
	}

	public void setChangeTime(Timestamp changeTime) {
		this.changeTime = changeTime;
	}

}