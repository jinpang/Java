package com.bienCloud.platform.po;

/**
 * TChargesItem entity. @author MyEclipse Persistence Tools
 */

public class TChargesItem implements java.io.Serializable {

	// Fields

	private Integer id;
	private String serviceCode;
	private String itemName;
	private Integer type;
	private Integer state;
	private String remark;

	// Constructors

	/** default constructor */
	public TChargesItem() {
	}

	/** minimal constructor */
	public TChargesItem(Integer id) {
		this.id = id;
	}

	/** full constructor */

	public TChargesItem(Integer id, String serviceCode, String itemName, Integer type,
			Integer state, String remark) {
		super();
		this.id = id;
		this.serviceCode = serviceCode;
		this.itemName = itemName;
		this.type = type;
		this.state = state;
		this.remark = remark;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getItemName() {
		return this.itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}