package com.bienCloud.platform.po;

import java.util.List;


/**
 * TLog entity. @author MyEclipse Persistence Tools
 */

public class TLog implements java.io.Serializable {

	// Fields

	private String id;
	private String clazz;
	private String method;
	private String createTime;
	private String level;
	private Integer cost;
	private String detail;
	private String user;
	private TLogConfigService service;
	private List<TLogConfigField> fields;

	// Constructors

	/** default constructor */
	public TLog() {
	}

	/** minimal constructor */
	public TLog(String id) {
		this.id = id;
	}

	/** full constructor */
	public TLog(String id, String clazz, String method, String createTime,
			String level, Integer cost, String detail, String user) {
		this.id = id;
		this.clazz = clazz;
		this.method = method;
		this.createTime = createTime;
		this.level = level;
		this.cost = cost;
		this.detail = detail;
		this.user = user;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClazz() {
		return this.clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public String getMethod() {
		return this.method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getLevel() {
		return this.level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public Integer getCost() {
		return this.cost;
	}

	public void setCost(Integer cost) {
		this.cost = cost;
	}

	public String getDetail() {
		return this.detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public TLogConfigService getService() {
		return service;
	}

	public void setService(TLogConfigService service) {
		this.service = service;
	}

	public List<TLogConfigField> getFields() {
		return fields;
	}

	public void setFields(List<TLogConfigField> fields) {
		this.fields = fields;
	}

}