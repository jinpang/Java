package com.bienCloud.platform.po;

import java.sql.Timestamp;

/**
 * TStrategyLog entity. @author MyEclipse Persistence Tools
 */

public class TStrategyLog implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer strategyId;
	private Integer updateUserId;
	private String updateUserName;
	private Timestamp updateTime;
	private String content;

	// Constructors

	/** default constructor */
	public TStrategyLog() {
	}

	/** minimal constructor */
	public TStrategyLog(Integer id) {
		this.id = id;
	}

	/** full constructor */
	public TStrategyLog(Integer id, Integer strategyId, Integer updateUserId,
			String updateUserName, Timestamp updateTime, String content) {
		this.id = id;
		this.strategyId = strategyId;
		this.updateUserId = updateUserId;
		this.updateUserName = updateUserName;
		this.updateTime = updateTime;
		this.content = content;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getStrategyId() {
		return this.strategyId;
	}

	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}

	public Integer getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(Integer updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUpdateUserName() {
		return this.updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Timestamp getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}