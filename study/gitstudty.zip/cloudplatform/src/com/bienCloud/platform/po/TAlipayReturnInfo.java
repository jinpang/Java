package com.bienCloud.platform.po;

import java.sql.Timestamp;

/**
 * TAlipayReturnInfo entity. @author MyEclipse Persistence Tools
 */

public class TAlipayReturnInfo implements java.io.Serializable {

	// Fields

	private Integer id;
	private String tradeNo;
	private String outTradeNo;
	private String price;
	private String subject;
	private String body;
	private String buyerEmail;
 
	private String tradeStatus;
	private Timestamp addtime;
	private String ip;

	// Constructors

	/** default constructor */
	public TAlipayReturnInfo() {
	}

	/** full constructor */
	public TAlipayReturnInfo(String tradeNo, String outTradeNo, String price,
			String subject, String body, String buyerEmail,  String tradeStatus, Timestamp addtime) {
		this.tradeNo = tradeNo;
		this.outTradeNo = outTradeNo;
		this.price = price;
		this.subject = subject;
		this.body = body;
		this.buyerEmail = buyerEmail;
		 
		this.tradeStatus = tradeStatus;
		this.addtime = addtime;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTradeNo() {
		return this.tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	public String getOutTradeNo() {
		return this.outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getPrice() {
		return this.price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return this.body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getBuyerEmail() {
		return this.buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	 

	public String getTradeStatus() {
		return this.tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public Timestamp getAddtime() {
		return this.addtime;
	}

	public void setAddtime(Timestamp addtime) {
		this.addtime = addtime;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

}