package com.bienCloud.platform.po;

/**
 * TMonthBalance entity. @author MyEclipse Persistence Tools
 */

public class TMonthBalance implements java.io.Serializable {

	// Fields

	private Integer id;
	private String term;
	private Double amount;
	private Integer bankId;

	// Constructors

	/** default constructor */
	public TMonthBalance() {
	}

	/** minimal constructor */
	public TMonthBalance(Integer id) {
		this.id = id;
	}

	/** full constructor */
	public TMonthBalance(Integer id, String term, Double amount, Integer bankId) {
		this.id = id;
		this.term = term;
		this.amount = amount;
		this.bankId = bankId;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTerm() {
		return this.term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public Double getAmount() {
		return this.amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getBankId() {
		return this.bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

}