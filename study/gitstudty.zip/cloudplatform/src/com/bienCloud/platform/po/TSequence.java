package com.bienCloud.platform.po;

/**
 * TSequence entity. @author MyEclipse Persistence Tools
 */

public class TSequence implements java.io.Serializable {

	// Fields

	private String keyName;
	private long keyValue;

	// Constructors

	/** default constructor */
	public TSequence() {
	}

	/** minimal constructor */
	public TSequence(String keyName) {
		this.keyName = keyName;
	}

	/** full constructor */
	public TSequence(String keyName, long keyValue) {
		this.keyName = keyName;
		this.keyValue = keyValue;
	}
	
	// Property accessors
	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public long getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(long keyValue) {
		this.keyValue = keyValue;
	}

}