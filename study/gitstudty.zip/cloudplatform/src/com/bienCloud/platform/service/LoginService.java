package com.bienCloud.platform.service;

import com.bienCloud.platform.po.TUser;
 

public interface LoginService {
	
	public TUser login(String userCode,String password); 
	
	public TUser login(String userCode);
	
	
	public TUser updateUserInfo(TUser user);

}
