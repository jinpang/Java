package com.bienCloud.platform.service;

import com.bienCloud.core.common.dto.CommonDto;

public interface OweRecordService {
	/**
	 * 分页得到数据
	 * 
	 * @param pageSize
	 * @param pageNow
	 * @param condition
	 * @return
	 */
	public CommonDto getResult(int pageSize, int pageNow, String poClass,
			String condition);
	
}
