package com.bienCloud.platform.service;

public interface SequenceService {
	 /**
     * 获取下一个Sequence键值
     * @param keyName Sequence名称
     * @return 下一个Sequence键值
     */
    public long updateGetNextKeyValue(String keyName);
}
