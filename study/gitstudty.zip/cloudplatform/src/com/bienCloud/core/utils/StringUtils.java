package com.bienCloud.core.utils;

public class StringUtils {
	public static String trim(String str){
		if(str!=null){
			str = str.trim();
		}
		return str;
	}
	
	public static boolean equals(String s1, String s2) {
		return s1 != null ? s1.equals(s2) : s2 == null;
	}
	
	public static boolean isNull(String str) {
		return str == null || "".equals(str.trim());
	}
	
}
