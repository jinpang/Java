/**
 * 
 */
package com.bienCloud.core.common;

/**
 * <pre>
 * 处理结果
 * 		封装Service的处理结果。
 * </pre>
 * 
 * @author zhuxiaoqi xqzhu@biencloud.com
 * @version 1.00.00
 * 
 */
public class Result {

	/**
	 * 结果代码（默认1为成功，其它代码可自行定义）
	 */
	private int code;
	
	/**
	 * 处理结果提示
	 */
	private String message;
	
	/**
	 * 处理结果提示
	 */
	private Object object;

	public Result(int code, String message) {
		super();
		this.code = code;
		this.message = message;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}
	
}
