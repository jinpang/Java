package com.bienCloud.core.common.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyResourceBundle;

public class PropertyUtil {

	//根据 Bundle产生property
	public static Properties getPropObjFromBundle(String bundleName) {

		Properties objProp = new Properties();
		PropertyResourceBundle bundle = (PropertyResourceBundle) PropertyResourceBundle
				.getBundle(bundleName);
		Enumeration enm = bundle.getKeys();
		while (enm.hasMoreElements()) {
			String key = (String) enm.nextElement();
			String value = bundle.getString(key);
			objProp.setProperty(key, value);

		}
		return objProp;
	}

	//根据 File产生property
	public static Properties getPropObjFromFile(String filePath) {
		Properties objProp = new Properties();
		File file = new File(filePath);
		InputStream inStream = null;
		try {
			inStream = new FileInputStream(file);
			objProp.load(inStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        if(inStream != null){
        	try {
				inStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
		return objProp;
	}

	// 根据key读取value
	public static String readValue(String filePath, String key) {
		Properties props = new Properties();
		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(
					filePath));
			props.load(in);
			String value = props.getProperty(key);
			System.out.println(key + value);
			if(in != null){
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return value;
		} catch (Exception e) {
			e.printStackTrace();
			if(in != null){
				try {
					in.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			return null;
		}
	}

	// 读取properties的全部信息到一条List<Map>对象中
	public static List<Map> readPropertiesToList(String filePath) {
		Properties props = new Properties();
		List<Map> propertyList = new ArrayList<Map>();
		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(
					filePath));
			props.load(in);
			Enumeration en = props.propertyNames();
			while (en.hasMoreElements()) {
				String key = (String) en.nextElement();
				String property = props.getProperty(key);
				Map<String, String> m = new HashMap<String, String>();
				m.put(key, property);
				propertyList.add(m);
//				System.out.println(key + property);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(in != null){
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return propertyList;
	}
	
	// 读取properties的全部信息到一个Map<String, String>对象中
	public static Map<String, String> readPropertiesToMap(String filePath) {
		Properties props = new Properties();
		Map<String, String> propertyMap = new HashMap<String, String>();
		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(
					filePath));
			props.load(in);
			Enumeration en = props.propertyNames();
			while (en.hasMoreElements()) {
				String key = (String) en.nextElement();
				String property = props.getProperty(key);
				propertyMap.put(key, property);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(in != null){
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return propertyMap;
	}
	
	// 写入properties信息
	public static void writeProperties(String filePath, String parameterName,
			String parameterValue) {
		Properties prop = new Properties();
		InputStream fis = null;
		OutputStream fos = null;
		try {
			fis = new FileInputStream(filePath);
			// 从输入流中读取属性列表（键和元素对）
			prop.load(fis);
			// 调用 Hashtable 的方法 put。使用 getProperty 方法提供并行性。
			// 强制要求为属性的键和值使用字符串。返回值是 Hashtable 调用 put 的结果。
			fos = new FileOutputStream(filePath);
			prop.setProperty(parameterName, parameterValue);
			// 以适合使用 load 方法加载到 Properties 表中的格式，
			// 将此 Properties 表中的属性列表（键和元素对）写入输出流
			prop.store(fos, "Update '" + parameterName + "' value");
		} catch (IOException e) {
			System.err.println("Visit " + filePath + " for updating "
					+ parameterName + " value error");
		}
		if(fis != null){
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(fos != null){
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// 写入properties信息
	public static void writeProperties(String filePath, Properties prop) {
		OutputStream fos = null;
		try {
			// 从输入流中读取属性列表（键和元素对）
			if(prop != null){
			// 调用 Hashtable 的方法 put。使用 getProperty 方法提供并行性。
			// 强制要求为属性的键和值使用字符串。返回值是 Hashtable 调用 put 的结果。
			fos = new FileOutputStream(filePath);
			// 以适合使用 load 方法加载到 Properties 表中的格式，
			// 将此 Properties 表中的属性列表（键和元素对）写入输出流
			prop.store(fos, "Properties file config");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(fos != null){
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		String file = "C:\\Users\\Administrator\\Workspaces\\MyEclipse 10\\cloudplatform\\src\\com\\bienCloud\\platform\\config\\bank\\alipayConfig.properties";
		Map<String, String> m = PropertyUtil.readPropertiesToMap(file);
		System.out.println(m);
	}
}
