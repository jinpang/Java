package com.bienCloud.core.common.util;

import java.sql.*;


/**
* 简单的数据连接工具
*/
public class DBUtils {
    public static final String url = "jdbc:mysql://127.0.0.1:3306/testdb";
    public static final String username = "root";
    public static final String password = "root";
    public static final String driverClassName = "com.mysql.jdbc.Driver";


    /**
     * 获取数据库连接Connection
     *
     * @return 数据库连接Connection
     */
    public static Connection makeConnection() {
        Connection conn = null;
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }


    public static void main(String args[]) {
        testConnection();
    }


    /**
     * 测试连接方法
     */
    public static void testConnection() {
        Connection conn = makeConnection();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM mysql.user");
            while (rs.next()) {
                String s1 = rs.getString(1);
                String s2 = rs.getString(2);
                System.out.println(s1 + "\t" + s2);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
