package com.bienCloud.core.sys;
 

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger; 


 

public class ScheduleInit extends HttpServlet{
	
	private static final long serialVersionUID = 6813773135180089689L;
	
	private static Logger logger;
	
	public ScheduleInit(){
		 logger = Logger.getLogger(ScheduleInit.class);
		 try {
			init();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}
	
	/**
	* ��ʼ����ҵ����
	*/
	public void init() throws ServletException { 
		
		 
	}
}
