/**
 * 
 */
package com.bienCloud.core.log;

/**
 * <pre>
 * ServiceLog。
 * </pre>
 * 
 * @author zhuxiaoqi xqzhu@biencloud.com
 * @version 1.00.00
 * 
 */
public class ServiceLog {

	private String time;

	private String user;
	
	private String level;
	
	private String clazz;
	
	private String method;
	
	private String cost;
	
	private Object[] args;
	
	private Object result;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public Object[] getArgs() {
		return args;
	}

	public void setArgs(Object[] args) {
		this.args = args;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
	
	
}
