/*==============================================================*/
/* Database: platform                                           */
/*==============================================================*/
drop database if exists platform;

create database platform;

use platform;

drop table if exists t_user;


/*==============================================================*/
/* Table: t_user                                                */
/*==============================================================*/
CREATE TABLE `t_user` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`code` VARCHAR(80) NULL DEFAULT NULL,
	`name` VARCHAR(80) NULL DEFAULT NULL,
	`password` VARCHAR(80) NULL DEFAULT NULL,
	`sign_in_count` INT(11) NULL DEFAULT NULL,
	`type` INT(11) NULL DEFAULT NULL,
	`current_sign_time` DATETIME NULL DEFAULT NULL,
	`last_sign_time` DATETIME NULL DEFAULT NULL,
	`current_sign_ip` VARCHAR(20) NULL DEFAULT NULL,
	`last_sign_ip` VARCHAR(20) NULL DEFAULT NULL,
	`state` INT(11) NULL DEFAULT NULL,
	`email` VARCHAR(100) NULL DEFAULT NULL,
	`status` INT(2) NULL DEFAULT NULL,
	`activation_code` VARCHAR(50) NULL DEFAULT NULL,
	`activation_time` DATETIME NULL DEFAULT NULL,
	`cellphone` VARCHAR(20) NULL DEFAULT NULL,
	`addtime` DATETIME NULL DEFAULT NULL,
	`company_id` INT(11) NULL DEFAULT NULL,
	`account_id` INT(11) NULL DEFAULT NULL,
	PRIMARY KEY (`id`),
	INDEX `company_id` (`company_id`),
	INDEX `account_id` (`account_id`),
	CONSTRAINT `t_user_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `t_company` (`id`),
	CONSTRAINT `t_user_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`)
)
COMMENT='-1 : 未激活  0  : 正常'
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=77;

comment on column t_user.code is 
'用户代码';

comment on column t_user.name is 
'用户名';

comment on column t_user.password is 
'密码';

comment on column t_user.sign_in_count is 
'登录次数';

comment on column t_user.type is 
'用户类型，1管理员，2运维人员，3财务人员，4用户管理员，5普通用户';

comment on column t_user.current_sign_time is 
'当前登录时间';

comment on column t_user.last_sign_time is 
'上次登录时间';

comment on column t_user.current_sign_ip is 
'当前登录IP';

comment on column t_user.last_sign_ip is 
'上次登录IP';

comment on column t_user.state is 
'状态1，正常，0冻结';

comment on column t_user.addtime is 
'添加时间';

comment on column t_user.company_id is 
'用户所在公司';

comment on column t_user.account_id is 
'帐户ID';


drop table if exists t_charges_item;

/*==============================================================*/
/* Table: t_charges_item                                        */
/*==============================================================*/
create table t_charges_item 
(
   id                   int                            not null auto_increment,
   service_code         VARCHAR(80)                    NULL DEFAULT NULL UNIQUE,
   item_name            varchar(80)                    null,
   type                 int                            null,
   remark               varchar(80)                    null,
   constraint PK_T_CHARGES_ITEM primary key clustered (id)
);

comment on column t_charges_item.service_code is 
'收费项目代码';

comment on column t_charges_item.item_name is 
'收费项目名称';

comment on column t_charges_item.type is 
'类型 1:opentack,2:openshift';

comment on column t_charges_item.remark is 
'备注';


drop table if exists t_charges_strategy;

/*==============================================================*/
/* Table: t_charges_strategy                                    */
/*==============================================================*/
create table t_charges_strategy 
(
   id                   int                            not null auto_increment,
   item_id              int                            null,
   charge_mode          int                            null,
   price                float                          null,
   discount             float                          null,
   dis_star_ime         datetime                       null,
   dis_end_time         datetime                       null,
   addtime              datetime                       null,
   update_time          datetime                       null,
   update_user          varchar(50)                    null,
   constraint PK_T_CHARGES_STRATEGY primary key clustered (id)
);

comment on column t_charges_strategy.item_id is 
'收费项目';

comment on column t_charges_strategy.charge_mode is 
'收费方式,1按小时,2按天，3按周，4按月，5按季，6按年';

comment on column t_charges_strategy.price is 
'价格';

comment on column t_charges_strategy.discount is 
'折扣';

comment on column t_charges_strategy.dis_star_ime is 
'折扣开始时间';

comment on column t_charges_strategy.dis_end_time is 
'折扣结束时间';

comment on column t_charges_strategy.addtime is 
'添加时间';

comment on column t_charges_strategy.update_time is 
' 最后修改时间';

comment on column t_charges_strategy.update_user is 
'最后修改人';


drop table if exists t_strategy_log;

/*==============================================================*/
/* Table: t_strategy_log                                        */
/*==============================================================*/
create table t_strategy_log 
(
   id                   int                            not null auto_increment,
   strategy_id          int                            null,
   update_user_id       int                            null,
   update_user_name     varchar(50)                    null,
   update_time          datetime                       null,
   content              varchar(500)                   null,
   constraint PK_T_STRATEGY_LOG primary key clustered (id)
);

comment on column t_strategy_log.strategy_id is 
'策略id';

comment on column t_strategy_log.update_user_id is 
'用户id';

comment on column t_strategy_log.update_user_name is 
'用户名称';

comment on column t_strategy_log.update_time is 
'修改时间';

comment on column t_strategy_log.content is 
'修改内容';


drop table if exists t_user_order_service;

/*==============================================================*/
/* Table: t_user_order_service                                        */
/*==============================================================*/
create table t_user_order_service 
(
   id                   int                            not null auto_increment,
   user_id              int                            null,
   item_id              int                            null,
   start_time           datetime                       null,
   end_time             datetime                       null,
   state                int                            null,
   addtime              datetime                       null,
   constraint PK_T_USER_SERVICE primary key clustered (id),
   foreign key (user_id) references t_user (id),
   foreign key (item_id) references t_charges_item (id)
);

comment on column t_user_order_service.user_id is 
'用户id';

comment on column t_user_order_service.item_id is 
'服务id';

comment on column t_user_order_service.start_time is 
'开始时间';

comment on column t_user_order_service.end_time is 
'结束时间';

comment on column t_user_order_service.state is 
'状态';

comment on column t_user_order_service.addtime is 
'新增时间';


drop table if exists t_order;

/*==============================================================*/
/* Table: t_order                                               */
/*==============================================================*/
create table t_order 
(
   id                   int                            not null auto_increment,
   user_id              int                            null,
   order_no             varchar(20)                    null,
   item_id              int                            null,
   state                int                            null,
   remark               varchar(200)                   null,
   addtime              datetime                       null,
   constraint PK_T_ORDER primary key clustered (id)
);

comment on column t_order.user_id is 
'用户id';

comment on column t_order.order_no is 
'订单号';

comment on column t_order.item_id is 
'服务id';

comment on column t_order.state is 
'订单状态，0未支付，1支付成功，2支付失败，';

comment on column t_order.remark is 
'备注';

comment on column t_order.addtime is 
'订单产生时间';


drop table if exists t_account;

/*==============================================================*/
/* Table: t_account                                             */
/*==============================================================*/
create table t_account 
(
   id                   int                            not null auto_increment,
   account_code         varchar(80)                    null,
   name                 varchar(80)                    null,
   password             varchar(80)                    null,
   contacts             varchar(100)                   null,
   balance              float                          null,
   valid_date           varchar(20)                    null,
   safe_code            varchar(200)                   null,
   addtime              datetime                       null,
   update_time          datetime                       null,
   constraint PK_T_ACCOUNT primary key clustered (id)
);

comment on column t_account.account_code is 
'帐号';

comment on column t_account.name is 
'姓名';

comment on column t_account.password is 
'密码';

comment on column t_account.contacts is 
'联络方式';

comment on column t_account.balance is 
'余额';

comment on column t_account.valid_date is 
'有效期';

comment on column t_account.safe_code is 
'由账户、姓名、有效期和余额组成的检验串';

comment on column t_account.addtime is 
'添加时间';

comment on column t_account.update_time is 
'最后修改时间';


drop table if exists t_trade_record;

/*==============================================================*/
/* Table: t_trade_record                                        */
/*==============================================================*/
create table t_trade_record 
(
   id                   int                            not null auto_increment,
   account_id           int                            null,
   account_code         varchar(80)                    null,
   amount               float                          null,
   order_no             varchar(20)                    null,
   state                int                            null,
   "comment"            varchar(200)                   null,
   ip                   varchar(20)                    null,
   trade_time           datetime                       null,
   constraint PK_T_TRADE_RECORD primary key clustered (id)
);

comment on column t_trade_record.account_id is 
'帐号id';

comment on column t_trade_record.account_code is 
'帐号';

comment on column t_trade_record.amount is 
'交易金额';

comment on column t_trade_record.order_no is 
'订单Id';

comment on column t_trade_record.state is 
'支付状态，0失败，1成功，';

comment on column t_trade_record."comment" is 
'交易内容';

comment on column t_trade_record.ip is 
'IP地址';

comment on column t_trade_record.trade_time is 
'交易时间';


drop table if exists t_recharge;

/*==============================================================*/
/* Table: t_recharge                                            */
/*==============================================================*/
create table t_recharge 
(
   id                   int                            not null auto_increment,
   amount               float                          null,
   bank                 varchar(50)                    null,
   bank_code            varchar(50)                    null,
   state                int                            null,
   company_id           int                            null,
   company_name         varchar(50)                    null,
   recharge_time        datetime                       null,
   user_id              int                            null,
   remark               varchar(200)                   null,
   constraint PK_T_RECHARGE primary key clustered (id)
);

comment on column t_recharge.amount is 
'充值金额';

comment on column t_recharge.bank is 
'充值银行名';

comment on column t_recharge.bank_code is 
'充值银行代码';

comment on column t_recharge.state is 
'充值状态,0成功，1失败';

comment on column t_recharge.company_id is 
'充值接口商家id，';

comment on column t_recharge.company_name is 
'充值商家名称';

comment on column t_recharge.recharge_time is 
'充值时间';

comment on column t_recharge.user_id is 
'充值用户';

comment on column t_recharge.remark is 
'备注';


drop table if exists t_bank;

/*==============================================================*/
/* Table: t_bank                                                */
/*==============================================================*/
create table t_bank 
(
   id                   int                            not null auto_increment,
   bank_code            varchar(50)                    null,
   bank_name            varchar(50)                    null,
   state                int                            null,
   addtime              datetime                       null,
   constraint PK_T_BANK primary key clustered (id)
);

comment on column t_bank.bank_code is 
'支付银行代码';

comment on column t_bank.bank_name is 
'支付银行名称';

comment on column t_bank.state is 
'状态，0不可用，1，正常使用';

comment on column t_bank.addtime is 
'添加时间';


drop table if exists t_month_balance;

/*==============================================================*/
/* Table: t_month_balance                                       */
/*==============================================================*/
create table t_month_balance 
(
   id                   int                            not null auto_increment,
   term                 varchar(10)                    null,
   amount               double                         null,
   bank_id              int                            null,
   constraint PK_T_MONTH_BALANCE primary key clustered (id)
);

comment on column t_month_balance.term is 
'年月';

comment on column t_month_balance.amount is 
'金额';

comment on column t_month_balance.bank_id is 
'银行';


drop table if exists t_company;

/*==============================================================*/
/* Table: t_company                                             */
/*==============================================================*/
create table t_company 
(
   id                   int                            not null auto_increment,
   company_code         varchar(80)                    not null unique,
   name                 varchar(80)                    null,
   contact              varchar(30)                    null,
   mobilephone          varchar(20)                    null,
   telephone            varchar(20)                    null,
   fax                  varchar(20)                    null,
   email                varchar(100)                   null,
   site                 varchar(300)                   null,
   address              varchar(100)                   null,
   postal_no            varchar(20)                    null,
   content              varchar(500)                   null,
   constraint PK_T_COMPANY primary key clustered (id)
);

comment on column t_company.id is 
'公司ID号';

comment on column t_company.company_code is 
'公司代码';

comment on column t_company.name is 
'公司名称';

comment on column t_company.contact is 
'联系人';

comment on column t_company.mobilephone is 
'手机号码';

comment on column t_company.telephone is 
'公司电话';

comment on column t_company.fax is 
'公司传真';

comment on column t_company.email is 
'公司邮件';

comment on column t_company.site is 
'公司网址';

comment on column t_company.address is 
'公司地址';

comment on column t_company.postal_no is 
'公司邮编';

comment on column t_company.content is 
'公司简介';


drop table if exists t_trade_record;

/*==============================================================*/
/* Table: t_trade_record                                        */
/*==============================================================*/
create table t_trade_record 
(
   id                   int                            not null auto_increment,
   account_id           int                            null,
   amount               float                          null,
   order_no             varchar(20)                    null,
   state                int                            null,
   type                 int                            null,
   account_balance      float                          null,
   comment              varchar(200)                   null,
   ip                   varchar(20)                    null,
   trade_time           datetime                       null,
   constraint PK_T_TRADE_RECORD primary key clustered (id)
);

comment on column t_trade_record.account_id is 
'帐号id';

comment on column t_trade_record.amount is 
'交易金额';

comment on column t_trade_record.order_no is 
'订单Id';

comment on column t_trade_record.state is 
'支付状态，0失败，1成功，';

comment on column t_trade_record.type is 
'交易类型1：充值；2：扣款';

comment on column t_trade_record.account_balance is 
'交易后余额';

comment on column t_trade_record."comment" is 
'交易内容';

comment on column t_trade_record.ip is 
'IP地址';

comment on column t_trade_record.trade_time is 
'交易时间';



drop table if exists t_activity_detail;

/*==============================================================*/
/* Table: t_activity_detail                                     */
/*==============================================================*/
create table t_activity_detail 
(
   id                   int                            not null auto_increment,
   trade_id             int                            null,
   user_order_id        int                            null,
   item_name            varchar(80)                    null,
   price                float                          null,
   price_unit           varchar(20)                    null,
   use_time             float                          null,
   amount               float                          null,
   activity_date        varchar(7)                     null,
   constraint PK_T_ACTIVITY_DETAIL primary key clustered (id),
   foreign key (trade_id) references t_trade_record (id),
   foreign key (user_order_id) references t_user_order_service (id)
);

comment on column t_activity_detail.id is 
'帐单明细ID';

comment on column t_activity_detail.trade_id is 
'交易ID';

comment on column t_activity_detail.user_order_id is 
'用户订制服务ID';

comment on column t_activity_detail.item_name is 
'项目名称';

comment on column t_activity_detail.price is 
'单价';

comment on column t_activity_detail.use_time is 
'服务使用时间';

comment on column t_activity_detail.amount is 
'金额';


drop table if exists t_owe_record;
/*==============================================================*/
/* Table: t_owe_record                                     */
/*==============================================================*/
CREATE TABLE `t_owe_record` (
	`id` INT(10) NOT NULL auto_increment,
	`type` INT(10) NULL,
	`content` VARCHAR(300) NULL,
	`change_time` DATETIME NULL,
	account_id int null,
	PRIMARY KEY (`id`),
	foreign key (account_id) references t_account (id)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB;


drop table if exists t_freeze_money;
/*==============================================================*/
/* Table: t_freeze_money                                     */
/*==============================================================*/
CREATE TABLE `t_freeze_money` (
	`id` INT(11) NOT NULL auto_increment,
	`account_id` INT(11) NULL DEFAULT NULL,
	`account_code` VARCHAR(80) NULL DEFAULT NULL,
	`freeze_amount` FLOAT NULL DEFAULT NULL,
	`user_id` INT(11) NULL DEFAULT NULL,
	`state` INT(11) NULL DEFAULT NULL,
	`freeze_time` DATETIME NULL DEFAULT NULL,
	`ticket_code` VARCHAR(50) NULL DEFAULT NULL,
	`update_time` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='utf8_general_ci'
ENGINE=MyISAM;


/*==============================================================*/
/* Table: t_user insert demo data                               */
/*==============================================================*/
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('admin', 'admin', '123456', 2, 1, now(), now(), '192.168.0.84', '192.168.0.84',  1, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('jzpang@test.com', 'jzpang@test.com', '123456', 2, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('snfang@test.com', 'snfang@test.com', '123456', 2, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test2', 'test2', '123456', 2, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test3', 'test3', '123456', 3, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test4', 'test4', '123456', 4, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test5', 'test5', '123456', 5, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 3, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test6', 'test6', '123456', 1, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 4, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test7', 'test7', '123456', 1, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 5, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test8', 'test8', '123456', 4, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 6, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test9', 'test9', '123456', 2, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test11', 'test11', '123456', 3, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test12', 'test12', '123456', 3, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test13', 'test13', '123456', 1, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 3, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test14', 'test14', '123456', 5, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test15', 'test15', '123456', 5, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test16', 'test16', '123456', 3, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test17', 'test17', '123456', 5, 1, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test18', 'test18', '123456', 1, 2, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 3, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test19', 'test19', '123456', 1, 2, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(),  1, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test20', 'test20', '123456', 1, 2, now(), now(), '192.168.0.84', '192.168.0.84', 1, now(), 2, 1);
INSERT INTO t_user (code, name, password, sign_in_count, type, current_sign_time, last_sign_time, current_sign_ip, last_sign_ip, state, addtime, company_id, account_id) VALUES ('test21', 'test21', '123456', 2, 1, now(), now(), '192.168.0.84', '192.168.0.84', 0, now(), 2, 1);


/*==============================================================*/
/* Table: t_company insert demo data                               */
/*==============================================================*/
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00001', 'biencloud', 'habei', '15889484498', '075523618505', '075523618505', 'bienlcoud@biencloud.com','http://www.biencloud.com', 'address1', '525000', 'biencloud');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00002', 'company2', 'master', '15889484498', '075523618505', '075523618505', 'zgyd@yd.com','http://www.yd.com', 'address2', '525000', 'company2');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00003', 'company3', 'test', '15889484498', '075523618505', '075523618505', 'zgdx@dx.com','http://www.dx.com', 'address3', '525000', 'company3');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00004', 'company4', 'boss', '15889484498', '075523618505', '075523618505', 'zglt@lt.com','http://www.lt.com', 'address4', '525000', 'company4');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00005', 'company5', 'jhome', '15889484498', '075523618505', '075523618505', 'qq@qq.com','http://www.qq.com', 'address5', '525000', 'company5');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00006', 'IBM', 'jonb', '15889484498', '075523618505', '075523618505', 'ibm@ibm.com','http://www.ibm.com', 'address6', '525000', 'IBM');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00007', 'biencloud', 'habei', '15889484498', '075523618505', '075523618505', 'bienlcoud@biencloud.com','http://www.biencloud.com', 'address1', '525000', 'biencloud');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00008', 'company2', 'master', '15889484498', '075523618505', '075523618505', 'zgyd@yd.com','http://www.yd.com', 'address2', '525000', 'company2');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00009', 'company3', 'test', '15889484498', '075523618505', '075523618505', 'zgdx@dx.com','http://www.dx.com', 'address3', '525000', 'company3');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00010', 'company4', 'boss', '15889484498', '075523618505', '075523618505', 'zglt@lt.com','http://www.lt.com', 'address4', '525000', 'company4');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00011', 'company5', 'jhome', '15889484498', '075523618505', '075523618505', 'qq@qq.com','http://www.qq.com', 'address5', '525000', 'company5');
INSERT INTO t_company (company_code, name, contact, mobilephone, telephone, fax, email, site, address, postal_no, content) VALUES ('company00012', 'IBM', 'jonb', '15889484498', '075523618505', '075523618505', 'ibm@ibm.com','http://www.ibm.com', 'address6', '525000', 'IBM');


/*==============================================================*/
/* Table: t_user_order_service insert demo data                               */
/*==============================================================*/
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (1, 1, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (2, 2, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (3, 3, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (4, 2, now(), now(), 0, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (5, 3, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (7, 2, now(), now(), 0, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (8, 3, now(), now(), 0, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (9, 2, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (2, 2, now(), now(), 0, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (1, 1, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (2, 3, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (3, 1, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (4, 2, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (2, 2, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (1, 1, now(), now(), 1, now());
INSERT INTO t_user_order_service (user_id, item_id, start_time, end_time, state, addtime) VALUES (1, 1, now(), now(), 1, now());

/*==============================================================*/
/* Table: t_trade_record insert demo data                               */
/*==============================================================*/
INSERT INTO t_trade_record (account_id, amount, order_no, state, type, account_balance, comment, ip, trade_time) VALUES (1, 1, 1, 1, 2, 100, '通过在线银行支付', '192.168.0.84', now());
INSERT INTO t_trade_record (account_id, amount, order_no, state, type, account_balance, comment, ip, trade_time) VALUES (1, 1, 1, 1, 1, -10, '购买华北节点BGP 2M带宽<包时>首日费用', '192.168.0.84', now());
INSERT INTO t_trade_record (account_id, amount, order_no, state, type, account_balance, comment, ip, trade_time) VALUES (1, 1, 1, 1, 2, 100, '通过在线银行支付', '192.168.0.84', now());


/*==============================================================*/
/* Table: t_activity_detail insert demo data                               */
/*==============================================================*/
INSERT INTO t_activity_detail (trade_id, user_order_id, item_name, price, price_unit, use_time, amount, activity_date) VALUES (1, 1, 'mysql', 10, '元/小时', 1.5, 15, '2012-08';
INSERT INTO t_activity_detail (trade_id, user_order_id, item_name, price, price_unit, use_time, amount, activity_date) VALUES (1, 1, 'oracle', 5, '元/小时', 5, 25, '2012-08');
INSERT INTO t_activity_detail (trade_id, user_order_id, item_name, price, price_unit, use_time, amount, activity_date) VALUES (1, 1, 'cloud host', 2, '元/小时', 2, 4, '2012-08');
