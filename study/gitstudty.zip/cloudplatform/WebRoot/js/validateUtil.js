﻿//校验登录名：只能输入5-80个以字母开头、可带数字、“_”、“.”、“@”的字串 
function isRegisterUserName(s) {
	var patrn = /^[a-zA-Z]{1}([a-zA-Z0-9]|[._@]){4,79}$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

/** 
 * 检验公司名 
 * 取值范围为a-z,A-Z,0-9,"_",汉字
 * 公司名有最小长度和最大长度限制，比如公司名必须是5-80位 
 * */  
function isCompanyName(s) {
	var patrn = /[a-zA-Z0-9\u4e00-\u9fa5]{1,79}$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

/** 
 * 检验应用代码
 * 取值范围为a-z,A-Z,0-9
 * 应用代码有最小长度和最大长度限制，比如必须是5-80位 
 * */  
function isAppCode(s) {
	var patrn = /[a-zA-Z0-9]{5,79}$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

/** 
 * 检验应用名称 
 * 取值范围为a-z,A-Z,0-9,"_",汉字
 * 应用名称有最小长度和最大长度限制，比如必须是2-80位 
 * */  
function isAppName(s) {
	var patrn = /[a-zA-Z0-9\u4e00-\u9fa5]{2,79}$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

//校验用户姓名：只能输入1-30个以字母开头的字串 
function isTrueName(s) {
	var patrn = /^[a-zA-Z]{1,30}$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

//校验密码：只能输入6-80个字母、数字、下划线 
function isPasswd(s) {
//	var patrn = /^(\w){6,80}$/;
//	if (!patrn.exec(s))
//		return false;
	if(s.length < 6 || s.length > 80)
		return false;
	return true;
}

//校验普通电话、传真号码：可以“+”开头，除数字外，可含有“-” 
function isTel(s) {
	//var     patrn=/^[+]{0,1}(\d){1,3}[     ]?([-]?(\d){1,12})+$/; 
	var patrn = /^[+]{0,1}(\d){1,3}[     ]?([-]?((\d)|[     ]){1,12})+$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

//校验手机号码：必须以数字开头，除数字外，可含有“-” 
function isMobil(s) {
	var patrn = /^[+]{0,1}(\d){1,3}[     ]?([-]?((\d)|[     ]){1,12})+$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

//校验邮政编码 
function isPostalCode(s) {
	//var     patrn=/^[a-zA-Z0-9]{3,12}$/; 
	var patrn = /^[a-zA-Z0-9]{3,12}$/;
	if (!patrn.exec(s))
		return false;
	return true;
}

//校验邮箱 
function isEmail(s) 
{ 
var patrn=/^[a-zA-Z0-9_\-]{1,}@[a-zA-Z0-9_\-]{1,}\.[a-zA-Z0-9_\-.]{1,}$/; 
if (!patrn.exec(s))    
	return false;
  return true;
}

//校验货币格式 
function     isCurrency(s) 
{ 
var patrn=/^\d+(\.\d+)?$/; 
if  (!patrn.exec(s)) 
	return false;
return true;
}

//=========验证密码，并分密码等级====================
//@param:密码控件对象
//@param:结果显示控件ID

function chkpwd(obj, chkResultObjId) {
	var t = obj.value;
	var id = getResult(t);

	//定义对应的消息提示
	var msg = new Array(4);
	msg[0] = "密码过短。";
	msg[1] = "密码强度差。";
	msg[2] = "密码强度良好。";
	msg[3] = "密码强度高。";

	var sty = new Array(4);
	sty[0] = -45;
	sty[1] = -30;
	sty[2] = -15;
	sty[3] = 0;

	var col = new Array(4);
	col[0] = "gray";
	col[1] = "red";
	col[2] = "#ff6600";
	col[3] = "Green";

	//设置显示效果
	//var bImg="1.gif";//一张显示用的图片
	var sWidth = 300;
	var sHeight = 15;
	var Bobj = document.getElementById(chkResultObjId);

	Bobj.style.fontSize = "12px";
	Bobj.style.color = col[id];
	Bobj.style.width = sWidth + "px";
	Bobj.style.height = sHeight + "px";
	Bobj.style.lineHeight = sHeight + "px";
	//Bobj.style.background="url(" + bImg + ") no-repeat left " + sty[id] + "px";
	Bobj.style.textIndent = "20px";
	Bobj.innerHTML = "" + msg[id];
}

//定义检测函数,返回0/1/2/3分别代表无效/差/一般/强
function getResult(s) {
	if (s.length < 4) {
		return 0;
	}
	var ls = 0;
	if (s.match(/[a-z]/ig)) {
		ls++;
	}
	if (s.match(/[0-9]/ig)) {
		ls++;
	}
	if (s.match(/(.[^a-z0-9])/ig)) {
		ls++;
	}
	if (s.length < 6 && ls > 0) {
		ls--;
	}
	return ls
}
//=========验证密码，并分密码等级====================

