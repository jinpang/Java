$(function(){
	$(".left_menu ul:not(:eq(1))").hide();
	$(".left_menu div a").click(function(){$(".left_menu ul:visible").slideUp("slow");$(this).parent().next().slideDown("slow");return false;});
	$(".list_tab tbody tr").hover(function(){$(this).addClass("list_tab_hover");},function(){$(this).removeClass("list_tab_hover");});
});
	