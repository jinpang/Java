/**
 * 密码强度校验
 * @author zhuxiaoqi xqzhu@biencloud.com
 */
(function($) {

$.extend($.fn, {

	pswstrength: function( options ) {
		var settings = {
			container : $(this).parent(),
			strength : [ "Very Weak", "Weak", "Better",
						"Medium", "Strong", "Strongest" ]
		}
		settings = $.extend( true, {}, settings, options );
		
		var showel = $("<div></div>").appendTo($(settings.container))
				.addClass("pswstrength_strength").addClass("pswstrength_strength0");
		
		$(this).keyup(function() {
			var desc = passwordStrength($(this).val());
			showel.html(strength[desc]);
			showel.addClass("pswstrength_strength" + desc);
		});
		return $(this);
	},
	

	passwordStrength : function(password) {
		var score = 0;
		// if password bigger than 6 give 1 point
		if (password.length > 6)
			score++;
	
		// if password has both lower and uppercase
		// characters give 1 point
		if ((password.match(/[a-z]/))
				&& (password.match(/[A-Z]/)))
			score++;
	
		// if password has at least one number give 1 point
		if (password.match(/\d+/))
			score++;
	
		// if password has at least one special caracther
		// give 1 point
		if (password
				.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/))
			score++;
	
		// if password bigger than 12 give another 1 point
		if (password.length > 12)
			score++;
		
		return score;
	}
});


})(jQuery);
