$(function(){
	$('li:has(ul)').click(function(even){
         if(this == even.target){
           if($(this).children().is(':hidden')){
              $(this).children().show();
           }else{
              $(this).children().hide();
           }
         }
         return true;
      })
      .css('cursor','pointer')
      .click();
    $('li:not(:has(ul))').css({
       cursor:'default'
     });
	$(".list_tab tbody tr").hover(function(){$(this).addClass("list_tab_hover");},function(){$(this).removeClass("list_tab_hover");});
  $(".left_to:has(ul):first").click();
});
	