 

  $(document).ready(function() {
	           // $("#linkA").click();
    	
    	 $(".avtive").each(function(){
    		    $(this).removeClass();
    	  });
    	 var cateCode = $("_cateCode").val();
		  if('a'==cateCode||''==cateCode){
			  $("#allCat").addClass("avtive");
		  }else if('q'==cateCode){
			  $("#qushiCat").addClass("avtive");
		  }else if('r'==cateCode){
			  $("#remenCat").addClass("avtive");
		  }else if('w'==cateCode){
			  $("#weekCat").addClass("avtive");
		  }else if('u'==cateCode){
			  $("#userCat").addClass("avtive");
		  }else{
			  $("#"+cateCode).addClass("avtive");
		  }
    });	        
  
function searchApp(){
	var appName = $("#appName").val();
	if(appName!=''&&'查找应用名称'!=appName){
		appName = encodeURI(encodeURI(appName));
		window.location.href="cloudstore.action?appName="+appName;
	}else{
		window.location.href="cloudstore.action";
	}	        	
}

function appKeyup(){
	 if(event.keyCode == 13)
     {
		 searchApp(); 
     }
}
 