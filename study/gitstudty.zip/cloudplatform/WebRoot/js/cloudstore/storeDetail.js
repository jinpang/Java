 //放大镜
$(function(){
	
	 $(".avtive").each(function(){
	    $(this).removeClass();
  });
  var cateCode = $("_cateCode").val();
  if('a'==cateCode||''==cateCode){
  $("#allCat").addClass("avtive");
  }else if('q'==cateCode){
  $("#qushiCat").addClass("avtive");
  }else if('r'==cateCode){
  $("#remenCat").addClass("avtive");
  }else if('w'==cateCode){
  $("#weekCat").addClass("avtive");
  }else if('u'==cateCode){
  $("#userCat").addClass("avtive");
  }else{
	  $("#"+cateCode).addClass("avtive");
  }
  
$("#etalage").etalage({
    thumb_image_width: 386,
    thumb_image_height: 300,
    source_image_width: 800,
    source_image_height: 600,
    zoom_area_width: 320,
    zoom_area_height: 460,
    zoom_area_distance: 18,
    show_hint:false,
    autoplay: false
});
setTimeout('$("#item_gallery_c").remove()',2000);
$("span[name^='mon_']").attr("onclick","priceChange(1,this)");
$("span[name^='space_']").attr("onclick","priceChange(2,this)");
    countPrice();
});
 
 //点击事件
function priceChange(type,obj){
	
	var selId = obj.id;				
	if(type==1){					
		$("span[name^='mon_']").attr("class","Unactive");						
}else if(type==2){
	$("span[name^='space_']").attr("class","Unactive");		
$("#priceSpace").html(obj.attributes['v'].nodeValue);
}				
$("#"+selId).attr("class","Active"); 	
	countPrice();
	updateTimeAndInstall();
}
 
// 计算价格
function countPrice(){
	var feeHtml = $("#feeSpan").html();
var monV = $("span[name^='mon_'][class='Active']").attr("v");		
var spaceV = $("span[name^='space_'][class='Active']").attr("v");	
if(spaceV==undefined){
	spaceV = $("span[name^='space_']:first").attr("v");	
$("span[name^='space_']:first").attr("class","Active"); 	
}				
var totalAmount = parseInt(monV)*(parseInt(spaceV)+parseInt(feeHtml));
$("#totalAmount").html(totalAmount);
$("#_total").html(totalAmount);
}



 $(document).ready(function() { 
	 
        $('#_buy_and_install').click(function() { 
        	buyModelDialog(); 
        }); 
 
        $('#close').click(function() { 
            $.unblockUI(); 
            return false; 
        }); 
 
        $('#_do_buy_cancel').click(function() { 
        $.unblockUI(); 
        return false; 
    }); 
}); 
//显示购买并安装对话框
function buyModelDialog(){
	$.blockUI({ message: $('#modalBuySetup'), css: { top: '20%' } }); 
}

//点击购买并安装按键事件
function buySetup(){
	isLogin();
	$("#_do_buy").removeAttr("disabled");
$("#_app_name").removeAttr("disabled");
$("#_app_name_image").hide();
$("#alert").hide();
$("#_app_name").val('');
$("#modelBodyAndFooterId").show("fast");
$("#showResultId").hide();
$(".alert").hide();
}
 // 初始化
  $(function(){
	  updateTimeAndInstall();
      getAppDomain();
      getDomainSuffix();
      $("#showResultId").hide();
  $("#modalBuySetup").hide();
  });
 
 //change buy and install model dialog
 function updateTimeAndInstall(){
	 var monV = $("span[name^='mon_'][class='Active']").attr("v");		
 var spaceType = $("span[name^='space_'][class='Active']").attr("st");
 var spaceV = $("span[name^='space_'][class='Active']").attr("v");
 var fee = $("#feeSpan").attr("value");
 $("#_time").html(monV);
 $("#_spacetype").html(spaceType);
 $("#_feeSpan").html(parseInt(fee) + parseInt(spaceV));
 }			
//判断当前用户是否登录，如何没有登录跳到登录页面
function isLogin(){
	var callback = function(result) {
		var json = $.parseJSON(result);
		if (json.flag == false) {
			window.location.href = json.data;
		}
		return;
	};
	$.ajax({
		type : "POST",
	url : "/cloudstore/admin/isLogin.action",
	data : {"targetUrl" : window.location.href},
		success : callback
	});
}
//获取域名
function getAppDomain(){
	var callback = function(result) {
		var json = $.parseJSON(result);
		if (json.flag == true) {
			$("#_app_domain").val(json.data);
		$("#_app_domain").attr("disabled", "disabled");
		$("#_app_domain_image").show("fast");
	} else {
		$("#_app_domain_image").hide();
		$("#_app_domain").removeAttr("disabled");
	}
	return;
};
$.ajax({
	type : "POST",
	url : "/cloudstore/admin/getAppDomain.action",
		success : callback
	});
}
//获取主域名
function getDomainSuffix(){
	var callback = function(result) {
		var json = $.parseJSON(result);
		if (json.flag == true) {
			$("#_domainSuffix").html("." + json.data);
	} else {
		$.error(json.data);
	}
	return;
};
$.ajax({
	type : "POST",
	url : "/cloudstore/admin/getDomainSuffix.action",
		success : callback
	});
}
//校验应用名是否可用
function validateAppUrlName(){
	var appName = $.trim($("#_app_name").val());
if(appName == null || appName == ""){
	$("#_app_name_image").hide();
	$.error("应用名称不能为空");
	return false;
}
if($("#_app_domain").attr("disabled") != "disabled"){
	$("#_app_name_image").show("fast");
	$("#alert").hide();
	return false;
}
	
var callback = function(result) {
	var json = $.parseJSON(result);
	if (json.flag == true) {
		$("#alert").hide();
		$("#_app_name_image").show("fast");
	} else {
		$("#_app_name_image").hide();
		$.error(json.data);
	}
	return;
};
$.ajax({
	type : "POST",
	url : "/cloudstore/admin/validateAppUrlName.action",
	data : {"appName" : $("#_app_name").val()},
		success : callback
	});
}
//校验应用域名是否可用
function validateAppDomain(){
	var callback = function(result) {
		var json = $.parseJSON(result);
		if (json.flag == true) {
			$("#_app_domain_image").show("fast");
	} else {
		$("#_app_domain_image").hide();
		$.error(json.data);
	}
	return;
};
$.ajax({
	type : "POST",
	url : "/cloudstore/admin/validateAppDomain.action",
	data : {"domainId" : $("#_app_domain").val()},
		success : callback
	});
}
//进行购买并安装操作
function doBuy(){
	var monV = $("span[name^='mon_'][class='Active']").attr("v");		
var spaceC = $("span[name^='space_'][class='Active']").attr("id");	
var domainId = $.trim($("#_app_domain").val());
var appName = $.trim($("#_app_name").val());
if(monV==undefined){
	$.error('请选择购买月数');
	return false;
}
if(spaceC==undefined){
	$.error('请选择云空间类型');
	return false;
}
if(domainId == ""){
	$.error('请输入域名');
	return false;
}
if(appName == ""){
	$.error('请输入应用名称');
	return false;
}
if($("#_app_name_image").is(":hidden")){
	$.error('请输入合法应用名称');
	return false;
}
if($("#_app_domain_image").is(":hidden")){
	$.error('请输入合法的域名');
	return false;
}

var data = {
	"app.code" : $("#appCode").val(),
	"domainId" : domainId,
	"appName" : appName,
	"month" : monV,
	"spaceCode" : spaceC
};

var callback = function(result) {
	var json = $.parseJSON(result);
	buyModelDialog(); 
	if (json.flag == true) {
		$("#modelBodyAndFooterId").hide();
		showResult(json.data);
	} else {
		$.error(json.msg);
	}
	return;
};

$.ajax({
	type : "POST",
	url : "/cloudstore/admin/createTemplateApp.action",
	data : data,
	beforeSend:function(){
		$("#_do_buy").attr("disabled", "disabled");
		$("#_app_name").attr("disabled", "disabled");
		$.blockUI({ message: "<h1>请稍等，正在为您安装...</h1>" }); 
    },
    complete:function(){
        //方法执行完毕，效果自己可以关闭，或者隐藏效果
    },
	success : callback,
	error:function(){
	      //数据加载失败
		}
	});
	
}
//购买成功后显示数据结果
function showResult(data){
    $("#showResultId").show("fast");
var str = "<h3><center>恭喜您！应用创建成功。</center></h3>您可以通过以下的链接开始你的应用：<br/><a href='" + data.app_msg.app_url + "' target='_blank'>" + data.app_msg.app_url + "</a><br/>";
$("#_app_msg_id").html(str);
    return;
}
//信息提示事件
(function() {
	$(function() {
		$("#alert").hide();
	$("#_app_name_image").hide();
	$("#_app_domain_image").hide();
});

$.tip = function(msg) {
	$("#alert").hide();
};

$.error = function(msg) {
	$("#alert").hide();
	$("#alert").html(msg).show("fast");
	};
}());    