biencloud cloudplatform logs
